package abc;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


public class CPUUtilization {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String command2 = " grep 'cpu' /proc/stat| awk '{usage=($2+$4)*100/($2+$5+$4)}END {print usage}'";
	      
        try {
        	
      	      JSch jsch=new JSch();
      	     
      	      String user = "ec2-user";
      	      int port = 22;
      	      String privateKey = "C:\\eclipse-jee-mars-R-win32-x86_64\\test2.pem";
      	      
      	    jsch.addIdentity(privateKey);
    	      System.out.println("identity added ");
      	    
    	      List<Float> val = new ArrayList<Float>();
      	      List<String> host = new ArrayList<String>();
  		       host.add("35.154.179.118");
  		       host.add("35.154.188.41");
  		       host.add("35.154.24.168");
  		       host.add("35.154.203.207");
  		         		        		        	      
  		     for(Object object : host) {
  		       String element = (String) object;
  		           	      
      	      Session session = jsch.getSession(user, element, port);
      	      System.out.println("session created.");
      	      java.util.Properties config = new java.util.Properties();
      	      config.put("StrictHostKeyChecking", "no");
      	      session.setConfig(config);

      	      session.connect();

	      	Channel channel=session.openChannel("exec");
	        ((ChannelExec)channel).setCommand(command2);
	        
	        channel.setInputStream(null);
	        ((ChannelExec)channel).setErrStream(System.err);
	        
	        InputStream in=channel.getInputStream();
	        channel.connect();
	        byte[] tmp=new byte[1024];
	        while(true){
	          while(in.available()>0){
	            int i=in.read(tmp, 0, 1024);
	            if(i<0)break;
	            
	            String result = new String (tmp, 0, i);
	            float x = Float.parseFloat(result);
	            val.add(x);
	            
	            System.out.print(result);
	          }
	          if(channel.isClosed()){
	            System.out.println("exit-status: "+channel.getExitStatus());
	            break;
	          }
	          try{Thread.sleep(1000);}catch(Exception ee){}
	        }
	        channel.disconnect();
	        session.disconnect();
	        System.out.println("DONE");
	    }
  		 
  		     Float y = Collections.max(val);
  		     Float z = Collections.min(val);
  		     System.out.println(y);
  		     System.out.println(z);
       }	     
        catch(Exception e){
	    	e.printStackTrace();
	    }
        	
  
	}

	private static Integer String(byte[] tmp, int i, int i2) {
		// TODO Auto-generated method stub
		return null;
	}
}
