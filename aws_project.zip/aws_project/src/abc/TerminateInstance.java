package abc;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.StopInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.lightsail.model.StopInstanceRequest;
public class TerminateInstance {

	
	private static String profileName = "default";
	private static Regions region = Regions.AP_SOUTH_1;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider(profileName);
			AmazonEC2Client amazonEC2Client = new AmazonEC2Client(credentialsProvider);
			amazonEC2Client.setRegion(Region.getRegion(region));
			
					    
			TerminateInstancesRequest instanceRequest = new TerminateInstancesRequest().withInstanceIds("i-048cb9de8d680757f");
		    amazonEC2Client.terminateInstances(instanceRequest);
		    System.out.println("instance terminated");

			}

}
