package abc;

import java.util.ArrayList;
import java.util.List;

import com.jcraft.jsch.*;

public class ConnectInstance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		    try{
		      JSch jsch=new JSch();

		      String user = "ec2-user";
		      int port = 22;
		      String privateKey = "C:\\eclipse-jee-mars-R-win32-x86_64\\test2.pem";

		      jsch.addIdentity(privateKey);
		      System.out.println("identity added ");
		      
		      List<String> host = new ArrayList<String>();
 		       host.add("35.154.179.118");
 		       host.add("35.154.188.41");
 		       host.add("35.154.24.168");
     	      
 		     for(Object object : host) {
 		       String element = (String) object;

		          Session session = jsch.getSession(user, element, port);
		          System.out.println("session created.");

		      
		         java.util.Properties config = new java.util.Properties();
		         config.put("StrictHostKeyChecking", "no");
		         session.setConfig(config);

		         session.connect();

		         Channel channel=session.openChannel("shell");

		         channel.setInputStream(System.in);
		      
		         channel.setOutputStream(System.out);

		         channel.connect(3*1000);
		      }
 		     
		    }
		    catch(Exception e){
		      System.out.println(e);
		    }
	}
				
		
}


