package abc;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.CreateKeyPairRequest;
import com.amazonaws.services.ec2.model.CreateKeyPairResult;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.KeyPair;
import com.amazonaws.services.ec2.model.RunInstancesRequest;

public class RunInstance {

	//private static String accessKey = "";
	//private static String secretKey = "";
	private static String profileName = "default";
	private static Regions region = Regions.AP_SOUTH_1;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider(profileName);
		AmazonEC2Client amazonEC2Client = new AmazonEC2Client(credentialsProvider);
		amazonEC2Client.setRegion(Region.getRegion(region));
		
/*		AWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
		AmazonEC2Client amazonEC2Client = new AmazonEC2Client(awsCredentials);
		amazonEC2Client.setRegion(Region.getRegion(region));
*/		
		/*		CreateKeyPairRequest createKeyPairRequest = new CreateKeyPairRequest();
		createKeyPairRequest.setKeyName("test");

		System.out.println("key created");
		*/
		
/*		CreateKeyPairResult createKeyPairResult = amazonEC2Client.createKeyPair(createKeyPairRequest);
		KeyPair keyPair = new KeyPair();

		keyPair = createKeyPairResult.getKeyPair();

		String privateKey = keyPair.getKeyMaterial();
*/		
		 List<String> securitygroup = new ArrayList<String>();
		 securitygroup.add("MySecurityGroup");
		
	    RunInstancesRequest instancesRequest = new RunInstancesRequest();
		instancesRequest.setImageId("ami-f9daac96");
		instancesRequest.setInstanceType(InstanceType.T2Micro);
		instancesRequest.setMinCount(1);
		instancesRequest.setMaxCount(1);
		instancesRequest.setKeyName("test");
		instancesRequest.setSecurityGroups(securitygroup);
		
		amazonEC2Client.runInstances(instancesRequest);
		System.out.println("instance created");
		
	}   
	 

}
