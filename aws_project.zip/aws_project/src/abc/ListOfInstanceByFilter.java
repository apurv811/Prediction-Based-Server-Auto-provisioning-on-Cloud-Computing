package abc;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.appstream.model.Session;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;

public class ListOfInstanceByFilter {

	private static String profileName = "default";
	private static Regions region = Regions.AP_SOUTH_1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        	  
		
		ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider(profileName);
		AmazonEC2Client amazonEC2Client = new AmazonEC2Client(credentialsProvider);
		amazonEC2Client.setRegion(Region.getRegion(region));
  
		DescribeInstancesResult describeInstances = amazonEC2Client.describeInstances();
        List<Reservation> reservations = describeInstances.getReservations();
      
        for (Reservation reservation : reservations) {
            List<Instance> instances = reservation.getInstances();
             for (Instance instance : instances) {
                 System.out.println("Instance Id :: " + instance.getInstanceId());
                 System.out.println("Instance Public Adress:: " + instance.getPublicIpAddress());
                 
                                  
             }
        }
        
        
        
	}
	
}
