package abc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;




public class Data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> date = new ArrayList<String>();
		
		
		//BufferedReader in = null;
		try {
		    		    
		    Scanner scanner = new Scanner(new File("C:\\eclipse-jee-mars-R-win32-x86_64\\StoredData_1.txt"));
		            
		    while(scanner.hasNext()){
		        String[] tokens = scanner.nextLine().split("\t");
		        String last = tokens[tokens.length-1];
		        date.add(last);
		               
		       // System.out.println(last);
		    }
		    
		    System.out.println(date.size());
		    
		    for (int i=0; i< date.size(); i++){
		    	Calendar cal = Calendar.getInstance();
		    	Date date1 = null;
		    	
				try {
					date1 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(date.get(i));
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	cal.setTime(date1);
		    	
		        System.out.println("Year  : " + cal.get(Calendar.YEAR));
		        System.out.println("Month : " + cal.get(Calendar.MONTH));
		        System.out.println("Day of Month : " + cal.get(Calendar.DAY_OF_MONTH));
		        System.out.println("Day of Week  : " + cal.get(Calendar.DAY_OF_WEEK));
		        System.out.println("Day of Year  : " + cal.get(Calendar.DAY_OF_YEAR));
		        System.out.println("Week of Year : " + cal.get(Calendar.WEEK_OF_YEAR));
		        System.out.println("Week of Month : " + cal.get(Calendar.WEEK_OF_MONTH));
		        System.out.println("Day of the Week in Month : " + cal.get(Calendar.DAY_OF_WEEK_IN_MONTH));
		        System.out.println("Hour  : " + cal.get(Calendar.HOUR));
		        System.out.println("AM PM : " + cal.get(Calendar.AM_PM));
		        System.out.println("Hour of the Day : " + cal.get(Calendar.HOUR_OF_DAY));
		        System.out.println("Minute : " + cal.get(Calendar.MINUTE));
		        System.out.println("Second : " + cal.get(Calendar.SECOND));
		    	
		    }
		    
		} catch (IOException e) {
		    System.out.println("There was a problem: " + e);
		    e.printStackTrace();
		} 

	}

}
