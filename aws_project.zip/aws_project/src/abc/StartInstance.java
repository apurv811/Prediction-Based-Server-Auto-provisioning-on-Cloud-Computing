package abc;

import java.util.*;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.StartInstancesRequest;
import com.amazonaws.services.ec2.model.StopInstancesRequest;
import com.amazonaws.services.lightsail.model.StartInstanceRequest;
import com.amazonaws.services.lightsail.model.StopInstanceRequest;

public class StartInstance {
	
	private static String profileName = "default";
	private static Regions region = Regions.AP_SOUTH_1;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider(profileName);
		AmazonEC2Client amazonEC2Client = new AmazonEC2Client(credentialsProvider);
		amazonEC2Client.setRegion(Region.getRegion(region));
		
	  List<String> instanceIds = new ArrayList<String>();
	  instanceIds.add("i-0aa7710170c91e86f");
	  //instanceIds.add(" ");
	  
		 StartInstancesRequest startRequest = new StartInstancesRequest(instanceIds);
	
		 amazonEC2Client.startInstances(startRequest);
		
	    System.out.println("instance started");

	}

}
