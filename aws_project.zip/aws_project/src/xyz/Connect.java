package xyz;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;

/**
 * Servlet implementation class Connect
 */
public class Connect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Connect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		List<String> ips = new ArrayList<>();
		List<String> id = new ArrayList<>();
	
		ips = (List<String>) session.getAttribute("Adreess");
		id = (List<String>) session.getAttribute("IstanceId");
		
		
		System.out.println("ip size :: " + ips.size());
		//System.out.println("id size :: " + id.size());
		List<Integer> k = new ArrayList<>();
		boolean check = true;
		List<Float> val = new ArrayList<Float>();
		//float arr[] = new float[4];
			    						
		
		String g = null;
		float a = 0;
		
		String host = null;
		
		
		for (int i = 0; i < ips.size(); i++) {
			try {
 			
				JSch jsch = new JSch();
                              
				String user = "ec2-user";
				host = ips.get(i);
				System.out.println(host);
				int port = 22;
				String privateKey = "C:\\eclipse-jee-mars-R-win32-x86_64\\test.pem";
				String command1 = "grep 'cpu' /proc/stat| awk '{usage=($2+$4)*100/($2+$5+$4)}END {print usage}' ";
			
				jsch.addIdentity(privateKey);
				System.out.println("identity added ");

				com.jcraft.jsch.Session jschsession = jsch.getSession(user, host, port);
				System.out.println("session created.");

				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				jschsession.setConfig(config);

				jschsession.connect();
				com.jcraft.jsch.Channel channel = jschsession.openChannel("exec");
				((ChannelExec) channel).setCommand(command1);
				channel.setInputStream(null);
				((ChannelExec) channel).setErrStream(System.err);

				InputStream in = channel.getInputStream();
				channel.connect();
				byte[] tmp = new byte[1024];
				while (check) {
					while (in.available() > 0) {
						int m = in.read(tmp, 0, 1024);
						if (m < 0)
							break;
						 g = (new String(tmp, 0, m));
						 a = Float.parseFloat(g);
						 
						System.out.println("CPU utilization of " + id.get(i) +" :: " + a);
					   val.add(a);
					}
					if (channel.isClosed()) {
/*						System.out.println(check);
						System.out.println("exit-status: " + channel.getExitStatus());
*/						break;
					}
					try {
						Thread.sleep(1000);
					} catch (Exception ee) {
						ee.printStackTrace();
					}
				}
				channel.disconnect();
				//jschsession.disconnect();
				
							
				
				
				
		
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
			
			
			
		}
		
		Float y = Collections.max(val);
		Float z = Collections.min(val);
		int index = val.indexOf(z);
		session.setAttribute("max", y);
		session.setAttribute("min", z);
		session.setAttribute("index", index);
		session.setAttribute("IstanceId",id);
		response.sendRedirect("MaxMinAutoScale");
		
		System.out.println("Maximum Value :: " +y);
		System.out.println("Minimum Value :: " +z);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
